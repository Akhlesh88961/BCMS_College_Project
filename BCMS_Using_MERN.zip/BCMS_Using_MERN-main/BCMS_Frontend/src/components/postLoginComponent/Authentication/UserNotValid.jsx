export default function UserNotValid() {
  return <h1>Invalid User</h1>;
}
